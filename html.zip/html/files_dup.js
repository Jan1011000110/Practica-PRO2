var files_dup =
[
    [ "Barco.cc", "Barco_8cc.html", null ],
    [ "Barco.hh", "Barco_8hh.html", [
      [ "Barco", "classBarco.html", "classBarco" ]
    ] ],
    [ "Cjt_ciudades.cc", "Cjt__ciudades_8cc.html", null ],
    [ "Cjt_ciudades.hh", "Cjt__ciudades_8hh.html", [
      [ "Cjt_ciudades", "classCjt__ciudades.html", "classCjt__ciudades" ]
    ] ],
    [ "Cjt_productos.cc", "Cjt__productos_8cc.html", null ],
    [ "Cjt_productos.hh", "Cjt__productos_8hh.html", [
      [ "Cjt_productos", "classCjt__productos.html", "classCjt__productos" ]
    ] ],
    [ "Cuenca.cc", "Cuenca_8cc.html", null ],
    [ "Cuenca.hh", "Cuenca_8hh.html", [
      [ "Cuenca", "classCuenca.html", "classCuenca" ]
    ] ],
    [ "Inventario.cc", "Inventario_8cc.html", null ],
    [ "Inventario.hh", "Inventario_8hh.html", [
      [ "Cantidad", "structCantidad.html", "structCantidad" ],
      [ "Inventario", "classInventario.html", "classInventario" ]
    ] ],
    [ "Producto.cc", "Producto_8cc.html", null ],
    [ "Producto.hh", "Producto_8hh.html", [
      [ "Producto", "classProducto.html", "classProducto" ]
    ] ],
    [ "program.cc", "program_8cc.html", "program_8cc" ]
];