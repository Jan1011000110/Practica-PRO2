var structCantidad =
[
    [ "poseido", "structCantidad.html#a2635b7d9f7562c749f0da6f0e5be4a00", null ],
    [ "requerido", "structCantidad.html#a35fad64d0a8c89ca1ea2d9db6b12e1e5", null ]
];