var classBarco =
[
    [ "Barco", "classBarco.html#aea54a1f00318af549e695999ccf08e38", null ],
    [ "agregar_viaje", "classBarco.html#a5dfabaa5594d73744183c4b21b543f3d", null ],
    [ "borrar_viajes", "classBarco.html#a0c10121667902699dfe5eb9fc98ea666", null ],
    [ "consultar_barco", "classBarco.html#a1d8beae9db574feab5e6b4e8d07c5bf2", null ],
    [ "escribir_barco", "classBarco.html#a3f1c26f2f0565e375924dae85b2e89a0", null ],
    [ "modificar_barco", "classBarco.html#a367058928ea7f359cbc1854eff4442b1", null ],
    [ "restante", "classBarco.html#aca280ae3722e21830a0cdd63f3245675", null ],
    [ "id_compra", "classBarco.html#a18ee6e2799fba957af616a42d54d005b", null ],
    [ "id_venta", "classBarco.html#a7dd3fe7762f9362219acc1fde2845504", null ],
    [ "num_compra", "classBarco.html#a7b8a9917814f1f80564f9cf95bfe465d", null ],
    [ "num_venta", "classBarco.html#a06142671610200b49d0a399cc6b0e2d7", null ],
    [ "viajes", "classBarco.html#a77b20c4f1a8a565f43462a522e2c4509", null ]
];