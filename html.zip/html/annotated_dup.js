var annotated_dup =
[
    [ "Barco", "classBarco.html", "classBarco" ],
    [ "Cantidad", "structCantidad.html", "structCantidad" ],
    [ "Cjt_ciudades", "classCjt__ciudades.html", "classCjt__ciudades" ],
    [ "Cjt_productos", "classCjt__productos.html", "classCjt__productos" ],
    [ "Cuenca", "classCuenca.html", "classCuenca" ],
    [ "Inventario", "classInventario.html", "classInventario" ],
    [ "Producto", "classProducto.html", "classProducto" ]
];