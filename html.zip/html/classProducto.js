var classProducto =
[
    [ "Producto", "classProducto.html#abdf37557185a4660251488b2db47fc7d", null ],
    [ "Producto", "classProducto.html#abf87cc63a1e018d20104cdb04d515dd2", null ],
    [ "consultar_peso", "classProducto.html#a90e4cd5cab49d54c688b6ae4bec890e4", null ],
    [ "consultar_volumen", "classProducto.html#ac51d2327dd5d4ff66029c7a985eab3f7", null ],
    [ "escribir_producto", "classProducto.html#af3546b67d16efa3ddc66caf069f0c3ec", null ],
    [ "leer_producto", "classProducto.html#ab6fe512a8aabc2ffb9be35646206e705", null ],
    [ "peso", "classProducto.html#a5432f079d648035abccdf978b5ab6c74", null ],
    [ "volumen", "classProducto.html#a6d13a8d1a5dbe354f421e14e88a08273", null ]
];