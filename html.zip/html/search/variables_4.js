var searchData=
[
  ['peso_151',['peso',['../classProducto.html#a5432f079d648035abccdf978b5ab6c74',1,'Producto']]],
  ['peso_5ftotal_152',['peso_total',['../classInventario.html#aba17fb21d17d1908f75fc27c6292bfe0',1,'Inventario']]],
  ['poseido_153',['poseido',['../structCantidad.html#a2635b7d9f7562c749f0da6f0e5be4a00',1,'Cantidad']]],
  ['productos_154',['productos',['../classCjt__productos.html#aa8b5bb2d5a8ffc5dc23441821a4a54ba',1,'Cjt_productos::productos()'],['../classCuenca.html#a710f881238488289a10dd94e28105bae',1,'Cuenca::productos()']]]
];
