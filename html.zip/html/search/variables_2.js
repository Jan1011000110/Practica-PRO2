var searchData=
[
  ['id_5fcompra_145',['id_compra',['../classBarco.html#a18ee6e2799fba957af616a42d54d005b',1,'Barco']]],
  ['id_5fventa_146',['id_venta',['../classBarco.html#a7dd3fe7762f9362219acc1fde2845504',1,'Barco']]],
  ['inv_147',['inv',['../classInventario.html#a0f6c269a5160f0399a7745a7e345a6fd',1,'Inventario']]]
];
