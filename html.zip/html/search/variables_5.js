var searchData=
[
  ['requerido_155',['requerido',['../structCantidad.html#a35fad64d0a8c89ca1ea2d9db6b12e1e5',1,'Cantidad']]]
];
