var searchData=
[
  ['quitar_5fproducto_70',['quitar_producto',['../classCjt__ciudades.html#af8904fcb4a201b93306f3984b2ae2f3f',1,'Cjt_ciudades::quitar_producto()'],['../classCuenca.html#aa7dbb8bd9399fc9322cd8913a8ce1d5b',1,'Cuenca::quitar_producto()'],['../classInventario.html#a1778706cec5564bcaa70f224945f5e94',1,'Inventario::quitar_producto()']]]
];
