var searchData=
[
  ['redistribuir_71',['redistribuir',['../classCuenca.html#a51870d649b499f3b73d4ea1532e2b526',1,'Cuenca::redistribuir()'],['../classCuenca.html#a774f43ab42455eed569b5000731625e6',1,'Cuenca::redistribuir(const BinTree&lt; string &gt; &amp;raiz)']]],
  ['requerido_72',['requerido',['../structCantidad.html#a35fad64d0a8c89ca1ea2d9db6b12e1e5',1,'Cantidad']]],
  ['restante_73',['restante',['../classBarco.html#aca280ae3722e21830a0cdd63f3245675',1,'Barco']]]
];
