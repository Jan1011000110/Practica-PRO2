var searchData=
[
  ['ciudades_143',['ciudades',['../classCjt__ciudades.html#a2ade4ab65c3151f4622e52c28734daf0',1,'Cjt_ciudades::ciudades()'],['../classCuenca.html#afadcf7affebe5218e4d3eb88595f23dd',1,'Cuenca::ciudades()']]]
];
