var searchData=
[
  ['num_5fcompra_56',['num_compra',['../classBarco.html#a7b8a9917814f1f80564f9cf95bfe465d',1,'Barco']]],
  ['num_5fventa_57',['num_venta',['../classBarco.html#a06142671610200b49d0a399cc6b0e2d7',1,'Barco']]],
  ['numero_5fde_5fproductos_58',['numero_de_productos',['../classCjt__productos.html#ab306e06db49ed36bf7cb31c524810d76',1,'Cjt_productos']]],
  ['numero_5fproductos_59',['numero_productos',['../classCjt__productos.html#ad13bf11505fd21a5a5825ca38c7d5a5f',1,'Cjt_productos::numero_productos()'],['../classCuenca.html#aea95fd8fb86b0cbb69f6001df5dcf9ac',1,'Cuenca::numero_productos()']]]
];
