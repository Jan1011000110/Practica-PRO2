var searchData=
[
  ['redistribuir_141',['redistribuir',['../classCuenca.html#a51870d649b499f3b73d4ea1532e2b526',1,'Cuenca::redistribuir()'],['../classCuenca.html#a774f43ab42455eed569b5000731625e6',1,'Cuenca::redistribuir(const BinTree&lt; string &gt; &amp;raiz)']]],
  ['restante_142',['restante',['../classBarco.html#aca280ae3722e21830a0cdd63f3245675',1,'Barco']]]
];
