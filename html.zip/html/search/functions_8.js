var searchData=
[
  ['numero_5fproductos_136',['numero_productos',['../classCjt__productos.html#ad13bf11505fd21a5a5825ca38c7d5a5f',1,'Cjt_productos::numero_productos()'],['../classCuenca.html#aea95fd8fb86b0cbb69f6001df5dcf9ac',1,'Cuenca::numero_productos()']]]
];
