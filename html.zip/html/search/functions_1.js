var searchData=
[
  ['barco_98',['Barco',['../classBarco.html#aea54a1f00318af549e695999ccf08e38',1,'Barco']]],
  ['borrar_5finventario_99',['borrar_inventario',['../classInventario.html#ad315d15ebbf2d5e233c776ce39aeaaea',1,'Inventario']]],
  ['borrar_5fviajes_100',['borrar_viajes',['../classBarco.html#a0c10121667902699dfe5eb9fc98ea666',1,'Barco']]]
];
