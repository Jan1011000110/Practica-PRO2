#include "Barco.hh"

Barco::Barco() 
{
    id_compra = 0;
    num_compra = 0;
    id_venta = 0;
    num_venta = 0;
}

void Barco::copiar_atributos(Barco &barco)
{
    id_compra = barco.consultar_id_compra();
    num_compra = barco.consultar_num_compra();
    id_venta = barco.consultar_id_venta();
    num_venta = barco.consultar_num_venta();
}

void Barco::modificar_barco(int id_compra, int num_compra, int id_venta, int num_venta)
{
    this->id_compra = id_compra;
    this->num_compra = num_compra;
    this->id_venta = id_venta;
    this->num_venta = num_venta;
}

void Barco::modificar_num_compra(int comercio)
{
    num_compra += comercio;
}

void Barco::modificar_num_venta(int comercio)
{
    num_venta += comercio;
}

void Barco::agregar_viaje(const string &ciudad_id) 
{
    viajes.push_back(ciudad_id);
}

void Barco::borrar_viajes()
{
    viajes.clear();
}

int Barco::consultar_id_compra() const
{
    return id_compra;
}

int Barco::consultar_num_compra() const
{
    return num_compra;
}

int Barco::consultar_id_venta() const
{
    return id_venta;
}

int Barco::consultar_num_venta() const
{
    return num_venta;
}

int Barco::restante() const
{
    return consultar_num_compra() + consultar_num_venta();
}

void Barco::escribir_barco() const
{
    cout << id_compra << " " << num_compra << " " << id_venta << " " << num_venta << endl;
    for (string ciudad : viajes)
    {
        cout << ciudad << endl;
    }
}